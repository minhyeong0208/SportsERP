// HeaderComponent 정의
const HeaderComponent = {
	template: ` 
        <div id="header">
            <h4>Soccer Team ERP</h4>
        </div>
    `
};
